<html>
<head>
  <title>Sweets Shop Order Receipts</title>
</head>
<body>
<h1>Receipt</h1>
<?php

$recTotal = 0.00;
  // create short variable names
  $searchtype=$_POST['searchtype'];
  $searchterm=trim($_POST['searchterm']);

  if (!$searchtype || !$searchterm) {
     echo 'You have not entered search details.  Please go back and try again.';
     exit;
  }

    $searchtype = addslashes($searchtype);
    $searchterm = addslashes($searchterm);

    $db = new mysqli('localhost', 'ihekwac1_cr_ss123', 'exM3KYUftdJ=', 'ihekwac1_cookierunsweetsshopdb'); //chnage to own db details

  if (mysqli_connect_errno()) {
     echo 'Error: Could not connect to database.  Please try again later.';
     exit;
  }

  $query = "select * from RECEIPT where ".$searchtype." like '%".$searchterm."%'";

  $result = $db->query($query);

  $num_results = $result->num_rows;
  
  echo "<h4>Order Receipt for Given Criteria: </h4>";
  
  echo "<p>Order processed at ".date('H:i, jS F Y')."</p>"; //temp value may extract this info from user side order page
  

  for ($i=0; $i <$num_results; $i++) {
    $row = $result->fetch_assoc();
    echo "<p><strong>".($i+1).". Product ID: ";
    echo htmlspecialchars(stripslashes($row['p_id']));
    echo "</strong><br />Product Name: ";
    echo stripslashes($row['productName']);
    echo "<br />Quantity: ";
    echo stripslashes($row['quantity']);
    echo "<br />Item Total: ";
    echo stripslashes($row['total']);

    $recTotal = $row['total'] += $recTotal;

    echo "</p>";
 }
 
     $o_id= $row['o_id'];
  $acc_id=$row['acc_id'];
  $u_email=$row['u_email'];
  $payType=$row['payType'];
  $shipAdd=$row['shipAdd'];
  
   $o_id = addslashes($o_id);
    $acc_id = addslashes($acc_id);
    $u_email = addslashes($u_email);
    $payType = addslashes($payType);
    $shipAdd = addslashes($shipAdd);

    echo "<p>Order ID: $o_id </p>";
    echo "<p>Account ID: $acc_id </p>";
    echo "<p>User Email: $u_email </p>";
    echo "<p>Payment Type: $payType </p>";
    echo "<p>Address: $shipAdd <p>";

 echo "Total: $recTotal";
 
 echo "<br><a href = 'manage_receipts.html'>Back to Receipt Search</a>";

  $result->free();
  $db->close();

?>
</body>
</html>
