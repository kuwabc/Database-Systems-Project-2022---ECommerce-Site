<?php 
  session_start();
  
  $id=$_POST["ProductID"];
  $qty=$_POST["quantity"];
  
  include "cart.class.php";
  $cart=new Cart();

  $cart->update_cart(["ProductID"=>$id,"quantity"=>$qty]);
  
  $result=[
	"row_total"=>$cart->get_item($id)["total"],
	"total"=>$cart->get_cart_total(),
  ];
  echo json_encode($result);
  
?>