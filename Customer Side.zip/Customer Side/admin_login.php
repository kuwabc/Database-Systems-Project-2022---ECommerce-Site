<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    
    header("location: admin_homepage.php");
    
    exit;
}
 
// Include config file
$db = new mysqli('localhost', 'ihekwac1_cr_ss123', 'exM3KYUftdJ=', 'ihekwac1_cookierunsweetsshopdb'); //chnage to own db details
 
// Define variables and initialize with empty values

$email = $adminpass = "";

$username_err = $password_err = $login_err = "";
 
// Processing form data when form is submitted

if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if username is empty
    
    if(empty(trim($_POST["email"]))){
        
        $username_err = "Please enter username.";
        
    } else{
        
        $email = trim($_POST["email"]);
    }
    
    // Check if password is empty
    
    if(empty(trim($_POST["adminpass"]))){
        
        $password_err = "Please enter your password.";
        
    } else{
        
        $adminpass = $_POST["password"];
    }
    
    // Validate credentials
    
    if(empty($username_err) && empty($password_err)){
        
        // Prepare a select statement
        
        $sql = "SELECT * FROM ADMINISTRATORS WHERE email = ?";
        
        if($stmt = $db->prepare($sql)){
            
            // Bind variables to the prepared statement as parameters
            
            $stmt->bind_param("s", $param_username);
            
            // Set parameters
            
            $param_username = $email;
            
            // Attempt to execute the prepared statement
            
            if($stmt->execute()){
                
                // Store result
                
                $stmt->store_result();
            
                
                // Check if username exists, if yes then verify password
                
                if($stmt->num_rows == 1){ 
                    
                    // Bind result variables
                    
                    $hashed_password = password_hash($_POST['adminpass'], PASSWORD_BYCRYPT);
                    
                    $adminpass = $_POST['adminpass'];
                    
                    $stmt->bind_result($adminID, $email, $hashed_password);
                    
                    if($stmt->fetch()){
                        
                        if(password_verify($adminpass, $hashed_password)){
                            
                            // Password is correct, so start a new session
                            
                            session_start();
                            
                            // Store data in session variables
                            
                            $_SESSION["loggedin"] = true;
                            
                            $_SESSION["adminID"] = $adminID;
                            
                            $_SESSION["email"] = $email;  
                            
                            // Redirect user to welcome page
                            
                            header("location: admin_homepage.php");
                            
                        } else{
                            
                            // Password is not valid, display a generic error message
                            
                            $login_err = "Invalid password.";
                            
                            
                        }
                    }
                } else{
                    // Username doesn't exist, display a generic error message
                    
                    $login_err = "Invalid or non-extistant username.";
                    
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            $stmt->close();
        }
    }
    
    // Close connection
    $db->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
    
</head>
<body>
    <h2>CR: Sweets Shop Admin Login</h2>
        <p>Please enter your account information to login</p>

        <?php
        // if there is a login error, display error message
        if(!empty($login_err)){
            echo '<div class="alert alert-danger">' . $login_err . '</div>';
            
        }        
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            
            <div class="form-group row">
                <label class = "col-form-label col-sm-2">Email</label>
               <div class = "col-sm-10"> <input type="text" name="email" class="form-control <?php echo (!empty($email_error)) ? 'is-invalid' : ''; ?>" value="<?php echo $email; ?>">
                <span class="invalid-feedback"><?php echo $email_error; ?></span></div>
           
                
            </div>    
            <div class="form-group row">
                <label class = "col-form-label col-sm-2 ">Password</label>
                <div class = "col-sm-10"><input type='password' name='adminpass' class="form-control <?php echo (!empty($password_error)) ? 'is-invalid' : ''; ?>">
                <span class="invalid-feedback"><?php echo $password_error; ?></span></div>
            
            
            </div>
            <div class="form-group">
                <div class= "offset-sm-2 col-sm-10">
                    <input type="submit" class="btn btn-primary" value="Login">
                </div>
            </div>
        </form>
    </div>
</body>
</html>