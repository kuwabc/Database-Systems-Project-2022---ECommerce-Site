<html>
<head>
  <title> Sweets Shop Order Cancellation</title>

</head>
<body>
<h1>Delete Order</h1>
  <p><a href = "admin_homepage.php">Admin Homepage</a> |
  <a href = "search.html">Search Product</a> |
  <a href = "new_item.html">Add Product</a> |
  <a href = "delete_item.html"> Delete Product</a> |
  <a href = "user_cart.html"> See Carts</a> | <!--make next 3-->
  <a href = "manage_user.html"> Manage Site Users</a> |
  <a href = "manage_orders.html"> Manage Site Orders</a> |
  <a href = "manage_receipts.html"> See Receipts</a> |
  <a href = "logout.php">Logout</a></p>
<?php

  // create short variable names
  $searchtype=$_POST['searchtype']; 
  $searchterm=$_POST['searchterm']; 

  
  if (!$searchtype || !$searchterm) {
     echo "You have not entered the required detail.<br />"
          ."Please go back and try again.";
     exit;
  }

  $searchtype = addslashes($searchtype);
  $searchterm = addslashes($searchterm);

$servername = "localhost";
$username = "ihekwac1_cr_ss123";
$password = "exM3KYUftdJ=";

$db = new mysqli('localhost', 'ihekwac1_cr_ss123', 'exM3KYUftdJ=', 'ihekwac1_cookierunsweetsshopdb'); //chnage to own db details

  $query = "delete from ORDERS where ".$searchtype." like '%".$searchterm."%'"; 
  $result = $db->query($query);
  
    $num_results = $result->num_rows;

  if ($num_results == 0) {
      echo "Order(s) not in Database.";
      echo "<br><a href = 'manage_orders.html'>Back to Site Orders</a>";
      exit;
  } 

  if ($result) {
    echo "Order(s) removed successfully!";
    echo "<br><a href = 'manage_orders.html'>Back to Site Orders</a>";

} else {
    echo "An error has occurred. Order(s) removal not successful.";
    echo "<br><a href = 'manage_orders.html'>Back to Site Orders</a>";
}

$db->close();
?>
</body>
</html>