<?php 
	include "config.php";
	session_start();
	
	include "cart.class.php";
	$cart=new Cart();
	
	if(isset($_POST["submit"])){
		//from HTML
		$name=mysqli_real_escape_string($con,$_POST["name"]);
		$email=mysqli_real_escape_string($con,$_POST["email"]);
		$paytype=mysqli_real_escape_string($con,$_POST["paytype"]);
		$cardnum=mysqli_real_escape_string($con,$_POST["cardnum"]);
		$secnum=mysqli_real_escape_string($con,$_POST["secnum"]);
		$address=mysqli_real_escape_string($con,$_POST["address"]);

		//(NAME,EMAIL,CONTACT,ADDRESS,CITY,PINCODE) values ('{$name}','{$email}','{$contact}','{$address}','{$city}','{$pincode}')";	
		
		#insert Order information
			$order_no=rand(10000,100000);
			$rec_no=rand(10000,100000);

			$total_amt=$cart->get_cart_total();

			$sql="insert into ORDERS (orderid, o_name, accID, u_email, payType, cardNum, secNum, shipAdd, total) values ('{$order_no}','{$name}','{$accID}','{$email}','{$paytype}','{$carnum}','{$secnum}', '{$total_amt}')";

			if($con->query($sql)){

				$accID=$con->insert_id;

				#insert receipt Item Details
				$sql="insert into RECEIPT (receipt_ID, o_id, acc_id, u_email, shipAdd, payType, total) values ('{$rec_no}','{$order_no}','{$accID}','{$email}','{$paytype}', '{$total_amt}')";
				$rows=[];
				foreach($cart->get_all_items() as $item){
					$rows[]="('{$oid}','{$item["id"]}','{$item["name"]}','{$item["price"]}','{$item["qty"]}','{$item["total"]}')";
				}

				$sql.=implode(",",$rows);
				if($con->query($sql)){
					$cart->destroy();
					header("location:complete.php?order_no={$order_no}");
				}
			}
			
		}
		
	}
?>
<html>
	<head>
        <title>Checkout</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    </head>
    <body>
		<?php include "navbar.php"; ?>
        <div class='container mt-5'>
			<h2 class='text-muted mb-4'>Delivery Details</h2>
			<div class='row'>
				<div class='col-md-6 mx-auto'>
					<form method='post' action='<?php echo $_SERVER["REQUEST_URI"];?>' autocomplete="off">
						<div class='form-group'>
							<label>Name (First and Last)</label>
							<input type='text' name='name' class='form-control' required placeholder='Name'>
						</div>
						<div class='form-group'>
							<label>Email</label>
							<input type='email' name='email' class='form-control' required placeholder='User Email'>
						</div>
						<div class='form-group'>
							<label>Payment Type</label>
							Card Type:<br />
    						<select name="paytype">
      						<option value="visa">VISA
      						<option value="mscd">MASTERCARD
							<option value="amex">AMERICAN EXPRESS
      						<option value="disc">DISCOVERY
      						<!--<option value="all">All-->
    						</select>
    						<br />
							</div>

							<div class='form-group'>
							<label>Card Number</label>
							<input type='text' name='cardnum' class='form-control' required placeholder='Card Number'>
						</div>

						<div class='form-group'>
							<label>Security Number</label>
							<input type='text' name='secnum' class='form-control' required placeholder='Security Number'>
						</div>

						<div class='form-group'>
							<label>Address</label>
							<input type='text' name='address' class='form-control' required placeholder='Full Address'>
						</div>
						<input type='submit' name='submit' value='Checkout' class='btn btn-primary'>
					</form>
				</div>
			</div>
		</div>
    </body>
</html> 