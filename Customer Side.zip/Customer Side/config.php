<?php 
	$db = new mysqli('localhost', 'ihekwac1_cr_ss123', 'exM3KYUftdJ=', 'ihekwac1_cookierunsweetsshopdb');
	if(!$db){
		die("Database Connection Failed");
	}
?>