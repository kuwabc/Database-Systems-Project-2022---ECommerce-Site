<?php
// Initialize the session
session_start();
 
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: admin_login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Cookie Run Sweets Shop</title>
            <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif; text-align: center; }
    </style>
    </head>
    <body>
        <div class="p-3 mb-2 bg-light text-dark"><h1>Welcome to CR:SS</h1>
            <h3>Administrator Homepage</h3>
            <nav class="navbar navbar-expand-sm justify-content-center">
            <ul class="navbar-nav">
                <li class="nav-item">
                  <a class="nav-link" href="search.html">Search Product</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="new_item.html">Add Product</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="update_item.html">Modify Product</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="delete_item.html">Delete Product</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="user_cart.html">See Carts</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="manage_user.html">Manage Site Users</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="manage_orders.html">Manage Site Orders</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="manage_receipts.html">See Receipts</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="logout.php">Logout</a>
                </li>
              </ul>
            </nav>
        </div>
        </div>
    </body>
</html>