<html>
<head>
  <title>Sweets Shop Product Edit</title>
</head>
<body>
<h1>Product Edit</h1>
<?php
  // create short variable names - ProductID, name, details, price, quantity
  $productID=$_POST['ProductID'];
  $name=$_POST['name'];
  $details=$_POST['details'];
  $price=$_POST['price'];
  $quant=$_POST['quantity'];

  if (!$productID && !$name && !$details && !$price && !$quant) {
     echo "You are not modifying the item.<br />"
          ."If this is a mistake, enter proper data or return to main menu.";
      echo "<br><a href = 'update_item.html'>Back to Item Update</a>";
     exit;
  }

  $product = addslashes($product);
  $name = addslashes($name);
  $details = addslashes($details);
  $price = doubleval($price);
  $quant = addslashes($quant);

  $servername = "localhost";
  $username = "ihekwac1_cr_ss123"; //make username for shop db - after work
  $password = "exM3KYUftdJ="; //make passwd for db

  $db = new mysqli('localhost', 'ihekwac1_cr_ss123', 'exM3KYUftdJ=', 'ihekwac1_cookierunsweetsshopdb'); //chnage to own db details

  if (mysqli_connect_errno()) {
     echo "Error: Could not connect to database.  Please try again later.";
     exit;
  }

  $query = "update PRODUCTS set
            name='".$name."' where ProductID = " .$productID; //possibly add an image
  $result = $db->query($query);

  if ($result) {
      echo "Edit Successful:";
      echo "<br><a href = 'update_item.html'>Back to Item Update</a>";
  } else {
  	  echo "An error has occurred.  The item was not added.";
  }

  $db->close();
?>
</body>
</html>
