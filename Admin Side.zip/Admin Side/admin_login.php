<?php
// Initialize the session
session_start();
 
// redirect to login page if user is logged in
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: admin_homepage.php");
    exit;
}
 
$servername = "localhost";
$username = "ihekwac1_cr_ss123";
$password = "exM3KYUftdJ=";

$db = new mysqli('localhost', 'ihekwac1_cr_ss123', 'exM3KYUftdJ=', 'ihekwac1_cookierunsweetsshopdb'); //chnage to own db details
 
$email = $adminpass= "";
$email_error = $password_error = $login_error = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if username is empty
    if(empty(trim($_POST["email"]))){
        $username_error = "Please enter email.";
    } else{
        $email = trim($_POST["email"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST["adminpass"]))){
        $password_error = "Please enter password.";
    } else{
        $adminpass = trim($_POST["adminpass"]);
    }
    
    // Validate username and password
    if(empty($email_error) && empty($password_error)){
        // query select statement to select adminID, email and password from administrators table where the email entered matches the email stored in the database
        $query = "SELECT adminID, email, adminpass FROM ADMINISTRATORS WHERE email = :email";

        if($result = $db->prepare($query)){
            $result->bindParam(":email", $param_email);
            $param_email = trim($_POST["email"]);
            
            if($result->execute()){

                // Check is email exists, then check is password matches with hashed password stored in the database
                if($result->rowCount() == 1){                    
                    if($row = $result->fetchassoc()){

                        $adminID = $row["adminID"];
                        $email = $row["email"];
                        $adminpass = $row["adminpass"];

                        $hashed_password = sha1("adminpass"); //must compare hashed version since every password is sha1 hashed

                        if(password_verify($adminpass, $hashed_password)){
                            //start session
                            session_start();

                            $_SESSION["loggedin"] = true;
                            $_SESSION["adminID"] = $adminID;
                            $_SESSION["email"] = $email;                            
                            
                            // Redirect user admin homepage if passwords and username match
                            header("location: admin_homepage.php");
                        } else{
                            $login_error = "Invalid username or password.";
                        }
                    }
                } else{
                    $login_error = "Invalid email or password.";
                }
            } else{
                echo "Something went wrong, please try again.";
            }
            // Close statement
            $result = null;
        }
    }
    // Close connection
    $db = null;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title> Admin Login</title>
</head>
<body>
    <h2>CR: Sweets Shop Admin Login</h2>
        <p>Please enter your account information to login</p>

        <?php
        // if there is a login error, display error message
        if(!empty($login_error)){
            echo '<div class="alert alert-danger">' . $login_error . '</div>';
        }        
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group row">
                <label class = "col-form-label col-sm-2">Email</label>
               <div class = "col-sm-10"> <input type="text" name="email" class="form-control <?php echo (!empty($email_error)) ? 'is-invalid' : ''; ?>" value="<?php echo $email; ?>">
                <span class="invalid-feedback"><?php echo $email_error; ?></span></div>
            </div>    
            <div class="form-group row">
                <label class = "col-form-label col-sm-2 ">Password</label>
                <div class = "col-sm-10"><input type="password" name="adminpass" class="form-control <?php echo (!empty($password_error)) ? 'is-invalid' : ''; ?>">
                <span class="invalid-feedback"><?php echo $password_error; ?></span></div>
            </div>
            <div class="form-group">
                <div class= "offset-sm-2 col-sm-10">
                    <input type="submit" class="btn btn-primary" value="Login">
                </div>
            </div>
        </form>
    </div>
</body>
</html>