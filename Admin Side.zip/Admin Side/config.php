<?php 
	$con=mysqli_connect("localhost","ihekwac1_cr_ss123","exM3KYUftdJ=","cookierunsweetsshopdb");
	if(!$con){
		die("Database Connection Failed");
	}
?>