<html>
<head>
  <title>Sweets Shop Search Results</title>
</head>
<body>
<h1>Search Results</h1>
<?php
  // create short variable names
  $searchtype=$_POST['searchtype'];
  $searchterm=trim($_POST['searchterm']);

  if (!$searchtype && !$searchterm) {
     echo 'You have not entered search details.  Please go back and try again.';
     echo "<br><a href = 'search.html'>Back to Product Search</a>";
     exit;
  }

  if ($searchtype && $searchtype === "all") {

    $searchtype = addslashes($searchtype);

    $db = new mysqli('localhost', 'ihekwac1_cr_ss123', 'exM3KYUftdJ=', 'ihekwac1_cookierunsweetsshopdb'); //chnage to own db details

  if (mysqli_connect_errno()) {
     echo 'Error: Could not connect to database.  Please try again later.';
     exit;
  }

  if ($searchtype === "all"){
    $query = "select * from PRODUCTS";
  }

  $result = $db->query($query);

  $num_results = $result->num_rows;

  echo "<h4>Number of products found: ".$num_results."</h4>";
  echo "<br><a href = 'search.html'>Back to Product Search</a>";

  for ($i=0; $i <$num_results; $i++) {
     $row = $result->fetch_assoc();
     echo "<p><strong>".($i+1).". Product ID: ";
     echo htmlspecialchars(stripslashes($row['ProductID']));
     echo "</strong><br />Product Name: ";
     echo stripslashes($row['name']);
     echo "<br />Price: ";
     echo stripslashes($row['price']);
     echo "<br />Current Quantity: ";
     echo stripslashes($row['quantity']);
     echo "</p>";
  }
  exit;
  $result->free();
  $db->close();
 }

 else{

    $searchtype = addslashes($searchtype);
    $searchterm = addslashes($searchterm);

    $db = new mysqli('localhost', 'ihekwac1_cr_ss123', 'exM3KYUftdJ=', 'ihekwac1_cookierunsweetsshopdb'); //chnage to own db details

  if (mysqli_connect_errno()) {
     echo 'Error: Could not connect to database.  Please try again later.';
     exit;
  }

  $query = "select * from PRODUCTS where ".$searchtype." like '%".$searchterm."%'";

  $result = $db->query($query);

  $num_results = $result->num_rows;

  echo "<h4>Number of products found: ".$num_results."</h4>";
  echo "<br><a href = 'search.html'>Back to Product Search</a>";

  for ($i=0; $i <$num_results; $i++) {
     $row = $result->fetch_assoc();
     echo "<p><strong>".($i+1).". Product ID: ";
     echo htmlspecialchars(stripslashes($row['ProductID']));
     echo "</strong><br />Product Name: ";
     echo stripslashes($row['name']);
     echo "<br />Price: ";
     echo stripslashes($row['price']);
     echo "<br />Current Quantity: ";
     echo stripslashes($row['quantity']);
     echo "</p>";
  }

  exit;
  $result->free();
  $db->close();
}

?>
</body>
</html>
