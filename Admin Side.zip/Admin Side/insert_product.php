<html>
<head>
  <title>Sweets Shop Product Entry</title>
</head>
<body>
<h1>Product Entry</h1>
<?php
  // create short variable names - ProductID, name, details, price, quantity
  $product=$_POST['ProductID'];
  $name=$_POST['name'];
  $details=$_POST['details'];
  $price=$_POST['price'];
  $quant=$_POST['quantity'];

  if (!$product || !$name || !$details || !$price || !$quant) {
     echo "Incomplete Entry.<br />"
          ."Please enter all product information.";
     exit;
  }

  $product = addslashes($product);
  $name = addslashes($name);
  $details = addslashes($details);
  $price = doubleval($price);
  $quant = addslashes($quant);

  $servername = "localhost";
  $username = "ihekwac1_cr_ss123"; //make username for shop db - after work
  $password = "exM3KYUftdJ="; //make passwd for db

  $db = new mysqli('localhost', 'ihekwac1_cr_ss123', 'exM3KYUftdJ=', 'ihekwac1_cookierunsweetsshopdb'); //chnage to own db details

  if (mysqli_connect_errno()) {
     echo "Error: Could not connect to database.  Please try again later.";
     exit;
  }

  $query = "insert into PRODUCTS values
            ('".$product."', '".$name."', '".$details."', '".$price."', '".$quant."')"; //possibly add an image
            
  $result = $db->query($query);

  if ($result) {
      echo "Product $name: Addition Successful!";
      echo "<br><a href = 'new_item.html'>Back to Add Product</a>";
  } else {
  	  echo "An error has occurred.  $name was not added.";
      echo "<br><a href = 'new_item.html'>Back to Add Product</a>";
  }

  $db->close();
?>
</body>
</html>
