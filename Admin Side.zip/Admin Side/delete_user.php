<html>
<head>
  <title> Sweets Shop User Removal</title>

</head>
<body>
<h1>Account Deletion</h1>
  <p><a href = "admin_homepage.php">Admin Homepage</a> |
  <a href = "search.html">Search Product</a> |
  <a href = "new_item.html">Add Product</a> |
  <a href = "delete_item.html"> Delete Product</a> |
  <a href = "user_cart.html"> See Carts</a> | <!--make next 3-->
  <a href = "manage_user.html"> Manage Site Users</a> |
  <a href = "manage_orders.html"> Manage Site Orders</a> |
  <a href = "manage_receipts.html"> See Receipts</a> |
  <a href = "logout.php">Logout</a></p>
<?php

  // create short variable names
  $AccountID=$_POST['AccountID']; 

  if (!$AccountID) {
     echo "You have not entered the required detail.<br />"
          ."Please go back and try again.";
     exit;
  }

    $AccountID = addslashes($AccountID);

$servername = "localhost";
$username = "ihekwac1_cr_ss123";
$password = "exM3KYUftdJ=";

$db = new mysqli('localhost', 'ihekwac1_cr_ss123', 'exM3KYUftdJ=', 'ihekwac1_cookierunsweetsshopdb'); //chnage to own db details

  $query = "delete from CUSTOMER where AccountID = ".$AccountID; 

  $result = $db->query($query);
  
  if ($result) {
    echo "User ID: $AccountID: Removal Successful!";
    echo "<br><a href = 'manage_user.html'>Back to Delete User</a>";

} else {
    echo "An error has User ID: $AccountID was not removed";
    echo "<br><a href = 'manage_user.html'>Back to Delete User</a>";
}

  //$db = null;
  $db->close();
?>
</body>
</html>