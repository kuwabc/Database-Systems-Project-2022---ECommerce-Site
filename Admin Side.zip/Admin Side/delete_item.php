<html>
<head>
  <title> Sweets Shop Delete Product</title>

</head>
<body>
<h1>Delete Product</h1>
  <p><a href = "admin_homepage.php">Admin Homepage</a> |
  <a href = "search.html">Search Product</a> |
  <a href = "new_item.html">Add Product</a> |
  <a href = "delete_item.html"> Delete Product</a> |
  <a href = "user_cart.html"> See Carts</a> | <!--make next 3-->
  <a href = "manage_user.html"> Manage Site Users</a> |
  <a href = "manage_orders.html"> Manage Site Orders</a> |
  <a href = "manage_receipts.html"> See Receipts</a> |
  <a href = "logout.php">Logout</a></p>
<?php

  // create short variable names
  $productID=$_POST['ProductID']; 
  $productName=$_POST['name']; 

  if (!$productID) {
     echo "You have not entered the required detail.<br />"
          ."Please go back and try again.";
     exit;
  }

    $productID = addslashes($productID);

$servername = "localhost";
$username = "ihekwac1_cr_ss123";
$password = "exM3KYUftdJ=";

$db = new mysqli('localhost', 'ihekwac1_cr_ss123', 'exM3KYUftdJ=', 'ihekwac1_cookierunsweetsshopdb'); //chnage to own db details

  $query = "delete from PRODUCTS where productID = ".$productID; 
  $result = $db->query($query);

  $num_results = $result->num_rows;

  if ($num_results == 0) {
      echo "Product not in Database.";
      echo "<br><a href = 'deleteproduct.html'>Back to Delete Product</a>";
  } 

  if ($result) {
    echo "Product ID: $productID: Removal Successful!";
    echo "<br><a href = 'delete_item.html'>Back to Delete Product</a>";

} else {
    echo "An error has occurred. ID: $productID was not removed";
    echo "<br><a href = 'delete_item.html'>Back to Delete Product</a>";
}

  //$db = null;
  $db->close();
?>
</body>
</html>