CREATE TABLE ADMINISTRATORS (
    adminID int(7) NOT NULL AUTO_INCREMENT,
    email varchar(255) NOT NULL,
    adminpass varchar(255) NOT NULL,

    PRIMARY KEY (adminID)
);

CREATE TABLE CUSTOMER (
    AccountID int(10) NOT NULL AUTO_INCREMENT,
    useremail varchar(255) NOT NULL,
    userpass varchar(255) NOT NULL,

    PRIMARY KEY (AccountID)
);

CREATE TABLE PRODUCTS (
    ProductID int(6) NOT NULL AUTO_INCREMENT,
    name varchar(255) NOT NULL DEFAULT '',
    details text,
    price double(10,2) NOT NULL DEFAULT '0.00',
    quantity int(10) NOT NULL DEFAULT '0',

    PRIMARY KEY (ProductID)
);

CREATE TABLE CART (
    cart_ID int(6) NOT NULL AUTO_INCREMENT,
    acc_ID int(6) NOT NULL,
    PID int(6) NOT NULL,
    ProductName varchar(255) NOT NULL,
    quantity int(10) NOT NULL DEFAULT '0',
    price double(10,2) NOT NULL DEFAULT '0.00', 

    PRIMARY KEY (cart_ID),
    FOREIGN KEY (PID) REFERENCES PRODUCTS(ProductID),
    FOREIGN KEY (acc_ID) REFERENCES CUSTOMERACCOUNT(AccountID)
);

CREATE TABLE ORDERS (
    orderid int(6) AUTO_INCREMENT,
    o_name varchar(255),
    u_email varchar(255),
    payType varchar(5),
    cardNum varchar(255),
    secNum varchar(255),
    shipAdd varchar(255),
    total double(10,2) DEFAULT '0.00', 

    PRIMARY KEY (orderid),

);

CREATE TABLE `ORDERS` (
  `orderid` int(6),
  `o_name` varchar(255),
  `u_email` varchar(255),
  `payType` varchar(5),
  `cardNum` varchar(50),
  `secNum` varchar(50),
  `shipAdd` varchar(255),
  `total` double(10,2) DEFAULT '0.00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE RECEIPT (
    receipt_ID int(10) AUTO_INCREMENT,
    o_id int(10) NOT NULL,
    acc_id int(10) NOT NULL,
    u_email varchar(255) NOT NULL,
    shipAdd varchar(255) NOT NULL,
    quantity int(10) NOT NULL DEFAULT '0',
    payType varchar(5) NOT NULL,
    total double(10,2) NOT NULL DEFAULT '0.00',

    PRIMARY KEY receipt_ID,
    FOREIGN KEY (o_id) REFERENCES ORDERS(orderid),
    FOREIGN KEY (acc_id) REFERENCES ORDERS(accID),

);