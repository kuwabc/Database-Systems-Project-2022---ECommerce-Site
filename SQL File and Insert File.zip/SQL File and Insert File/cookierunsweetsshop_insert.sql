INSERT INTO ADMINISTRATORS (adminID, email, adminpass) VALUES
(1, 'admin01@sweetshop.admin', 'f952bb8a40a01ae95bae7174923e7b83f2621c13'), --sourmelon12345@--
(2, 'admin02@sweetshop.admin', '771d0ecbebc47356ad4ba65a7ebadd9398bf2c4d'); --lazybonesjones--

INSERT INTO CUSTOMER (AccountID, useremail, userpass) VALUES
(1, 'nayohminty@sweetshop.bake', '123meloncookie'),
(2, 'outfitterbest@sweetshop.bake', 'skellsrc00l'),
(3, 'ancde@sweetshop.bake', '678ghythg'),
(4, 'blahblah@sweetshop.bake', 'password');

INSERT INTO PRODUCTS (ProductID, name, details, price, quantity) VALUES
(1, 'GingerBrave Cookie Acrylic Keychain', 'Have the bravest cookie in your kingdom guard your belongings with this snazzy acrylic matte finish charm!', 5.99, 1000),
(2, 'Strawberry Crepe Cookie Acrylic Keychain', 'Smart AND cute?! How could anyone resist? Be the talk of the oven with this keycharm!', 5.99, 1000),
(3, 'Black Peark Cookie T-Shirt', 'Whatever you do - avoid wearing this to the beach...the sea gets a bit restless for some reason...', 15.99, 1000),
(4, 'Afogatto Cookie Color-Block T-Shirt', 'A cookie born from two desserts, now on a color-blocked T-shirt! How clever - and kinda cool, too!', 15.99, 1000),
(5, 'Tea Knight Cookie Plushie', 'A cookie to keep those nasty cake hounds away - with a Halbred and...a faint tea scent as well...Grab this plushie while you can!', 25.99, 1000),
(6, 'Latte Cookie Plushie', 'There is no right way of doing things - just go with the flow! Everyone needs encouragement, so have a Latte Cookie plush to help!', 25.99, 1000);

INSERT INTO CART (cart_ID, acc_ID, PID, ProductName, quantity, price) VALUES
(1, 1, 1, 'GingerBrave Cookie Acrylic Keychain', 1, 5.99),
(2, 1, 5, 'Tea Knight Cookie Plushie', 1, 25.99),
(3, 1, 6, 'Latte Cookie Plushie', 1, 25.99);

INSERT INTO ORDERS (orderid, o_name, accID, u_email, payType, cardNum, secNum, shipAdd, total) VALUES
(1, 'Naomi Mint', 1, 'nayohminty@sweetshop.bake', 'VISA', '1234567890123456', '211', '1800 Dundham Lane, Earlgre, New Mexico, USA, 123456',62.00),

INSERT INTO RECEIPT (o_id, acc_id, p_id, productName, shipAdd, quantity, payType, total) VALUES
(1, 1, 1, 'GingerBrave Cookie Acrylic Keychain', '1800 Dundham Lane, Earlgre, New Mexico, USA, 123456', 1, 'VISA', 5.99),
(1, 1, 5, 'Tea Knight Cookie Plushie', '1800 Dundham Lane, Earlgre, New Mexico, USA, 123456', 1, 'VISA', 25.99),
(1, 1, 6, 'Latte Cookie Plushie', '1800 Dundham Lane, Earlgre, New Mexico, USA, 123456', 1, 'VISA', 25.99);
